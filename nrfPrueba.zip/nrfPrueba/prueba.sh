#! /bin/bash

sudo service mongod start
sudo node index.js
