const Gpio = require('onoff').Gpio;
const nrfInterrupt = new Gpio(27, 'in', 'falling');


const rf24js = require('rf24js');
var radio = rf24js.radio;
var PALevel = rf24js.PALevel;
var CRCLength = rf24js.CRCLength;
var Datarate = rf24js.Datarate;

const msgpack = require("msgpack-lite");

radio.create(22, 0); // RaspberryPi 1/2/3 
radio.begin();
radio.setPALevel(0);
radio.printDetails();

var pipe0 = new Buffer.from("0Node\0");
var pipe1 = new Buffer.from("1Node\0");
var pipe2 = new Buffer.from("2Node\0");
var pipe3 = new Buffer.from("3Node\0");
var pipe4 = new Buffer.from("4Node\0");

radio.openWritingPipe(pipe0);
radio.openReadingPipe(1, pipe1);
radio.openReadingPipe(2, pipe2);
radio.openReadingPipe(3, pipe3);
radio.openReadingPipe(4, pipe4);
radio.enableInterrupts(false, false, true);
radio.startListening();

var bufferPipe1 = Buffer.alloc(32);
var bufferPipe2 = Buffer.alloc(32);
var bufferPipe3 = Buffer.alloc(32);
var bufferPipe4 = Buffer.alloc(32);
var msgNoise = Buffer.alloc(256);
var msgAir = Buffer.alloc(256);
var msgWater = Buffer.alloc(256);
var msgPaper = Buffer.alloc(256);
var noise;
var airQuality;
var waterQuality
var paper

nrfInterrupt.watch(function(err,value) {
	if(err) {
		console.log(err);
	} else {
		var check = radio.availableFull();
		if(check.channel == 1) {
			bufferPipe1 = radio.read(32);
			console.log('Paquete %d de %d Air', bufferPipe1[0]+1, bufferPipe1[2]);
			//construirPaqueteNoise(bufferPipe1);
			construirPaquete(bufferPipe1, msgAir, airQuality);
		}
		if(check.channel == 2) {
			bufferPipe2 = radio.read(32);
			console.log('Paquete %d de %d Water', bufferPipe2[0]+1, bufferPipe2[2]);
			construirPaquete(bufferPipe2, msgWater, waterQuality);
		}
		if(check.channel == 3) {
			bufferPipe3 = radio.read(32);
			console.log('Paquete %d de %d Noise', bufferPipe3[0]+1, bufferPipe3[2]);
			//construirPaqueteAir(bufferPipe2);
			construirPaquete(bufferPipe3, msgNoise, noise);
		}
		if(check.channel == 4) {
			bufferPipe4 = radio.read(32);
			console.log('Paquete %d de %d paper', bufferPipe4[0]+1, bufferPipe4[2]);
			construirPaquete(bufferPipe4, msgPaper, paper);
		}
	}
});

process.on('SIGINT', () => {
	client.end();
	dbClient.close();
	nrfInterrupt.unexport();
});

function construirPaquete(paq, buf, deco) {
	var numPaq = paq[0];
	var id = paq[1]
	var numPaqTot = paq[2];
	var cantBytes = paq[3];
	
	paq.copy(buf,numPaq*28,4,cantBytes+4);
	if(numPaq == numPaqTot-1) {		
		deco = msgpack.decode(buf);
		//deco._id = new Date();
		if(deco.datetime == '2000-00-00T00:00:00Z' || deco.datetime == '2000-00-00T00:00:99Z' || deco.datetime == '2000-01-01T00:00:00Z') {
			deco._id = new Date();
		}
		else {
			deco._id = new Date(deco.datetime);
		}
		console.log(deco);
		if(client.connected) {
			client.publish(TOPIC, JSON.stringify(deco), { qos: 2});
			console.log('Mensaje publicado');
		}
		dbClient.connect(function(err) {
			assert.equal(null, err);
			console.log("Connected successfully to server");

			const db = dbClient.db(dbName);

			const collection = db.collection('documents');
			collection.insertOne(deco, function(err, res) {
				//if (err) throw err;
				if (err) {
					console.log(err);
				} else {
					console.log('1 document inserted');
				}
				//dbClient.close();
			});
		});
		
	}
}



//function construirPaqueteAir (bufAir) {
	//var numPaq = bufAir[0];
	//var id = bufAir[1]
	//var numPaqAir = bufAir[2];
	//var cantBytes = bufAir[3];
	
	//bufAir.copy(msgAir,numPaq*28,4,cantBytes+4);
	//if(numPaq == numPaqAir-1) {		
		//airQuality = msgpack.decode(msgAir);
		//console.log(airQuality);
		//if(client.connected) {
			//client.publish(TOPIC, JSON.stringify(airQuality));
			//console.log('publicado');
		//}
	//}
//}

const mqtt = require('mqtt');

var client = mqtt.connect('mqtt://mqtt.flespi.io:1883', { 
	username: 'BOiGGrUBnFEZqxq7qa4zQE9NQHtsEj84VgyrxiRILlvZGMWWMPmrhl4VSldls9dd',
	protocolVersion: 4,
	clientId: 'mqttjs_raspi'});
var TOPIC = 'custom';

client.on('connect', function () {
	console.log('conectado');
});

const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');


const url = 'mongodb://localhost:27017';
const dbName = 'mydb';

const dbClient = new MongoClient(url);



