var PALevel = rf24js.PALevel;
var CRCLength = rf24js.CRCLength;
var Datarate = rf24js.Datarate;

var msgpack = require('msgpack5')() // namespace our extensions
  , encode  = msgpack.encode
  , decode  = msgpack.decode

radio.create(22, 0); // RaspberryPi 1/2/3 
radio.begin();
radio.printDetails();

var pipe1 = new Buffer("1Node\0");
var pipe2 = new Buffer("2Node\0");
radio.openWritingPipe(pipe1);
radio.openReadingPipe(1, pipe2)

radio.startListening();

var buffer = null;
var buf1 = Buffer.alloc(31);
var buf2 = Buffer.alloc(31);
var buf3 = Buffer.alloc(31);
var buf4 = Buffer.alloc(31);
var len;
var pack = null
var cnt = 1

while(1)
{
	if (radio.available())
	{
		buffer = radio.read(32);
		console.log(buffer)
		console.log('dato %d',cnt++);
	}
}
