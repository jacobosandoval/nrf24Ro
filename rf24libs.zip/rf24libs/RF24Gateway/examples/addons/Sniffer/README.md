
   **RF24Network Scanner by TMRh20 Aug 2016**
   Outputs data to console & UDP port 32001
   See the LUA script for Wireshark at https://github.com/TMRh20/RF24Gateway/tree/master/examples/addons
   
   Impersonate any RF24Network/RF24Mesh/RF24Gateway node & scan traffic without disruption to the network
